var express = require('express');

module.exports = function(){
	var app = express();
	return app;
}