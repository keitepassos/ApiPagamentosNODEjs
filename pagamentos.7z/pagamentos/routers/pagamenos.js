

modulo.exports = function(app){
	app.get('/pagamentos', function(request, response){
	    console.log('Requisição ok');
	    response.send('ok');
	});

}

