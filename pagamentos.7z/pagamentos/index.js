
var app = require('./config/custom-express')();//carregou e incocou

app.listen(3000, function(){
	console.log('up')
});
